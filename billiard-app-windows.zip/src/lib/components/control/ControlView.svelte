<script>
  import { matchStore } from '../../stores/matchStore.js';
  import PlayerCard from './PlayerCard.svelte';
  import TickerAdmin from './TickerAdmin.svelte';
  import { ArrowLeftRight, Play, Pause, RotateCcw, Clock, ToggleLeft, ToggleRight, UserCheck, Image, Sliders } from 'lucide-svelte';

  $: timer = $matchStore.timer;
  $: turns = $matchStore.turns;
  $: showAvatars = $matchStore.showAvatars;
  $: uiScale = $matchStore.uiScale || { hud: 1.0, ticker: 1.0 };

  let customSecondsInput = 30;
</script>

<div class="min-h-screen bg-[#07080b] text-white p-6 font-sans flex flex-col gap-6">
  
  <!-- Barra Superior -->
  <header class="flex items-center justify-between border-b border-white/10 pb-4">
    <div>
      <h1 class="text-xl font-black tracking-wider uppercase font-mono text-amber-400">Panel de Control</h1>
      <p class="text-xs text-neutral-400">Control de partida en vivo para OBS Studio</p>
    </div>

    <!-- Acciones Rápidas -->
    <div class="flex items-center gap-3">
      
      <!-- DESLIZADORES DE ESCALA (HUD Y CINTA) -->
      <div class="flex items-center gap-3 bg-[#0a0c12] border border-neutral-800 px-3 py-1.5 rounded-xl">
        <Sliders size={14} class="text-amber-400" />
        
        <!-- Escala Marcador -->
        <div class="flex items-center gap-2">
          <span class="text-[10px] font-mono text-neutral-400 uppercase">Marcador:</span>
          <input
            type="range"
            min="0.70"
            max="1.50"
            step="0.05"
            value={uiScale.hud}
            on:input={(e) => matchStore.setHudScale(e.target.value)}
            class="w-16 accent-amber-500 h-1 bg-neutral-800 rounded cursor-pointer"
          />
          <span class="text-[10px] font-mono font-bold text-amber-400 w-8">{Math.round(uiScale.hud * 100)}%</span>
        </div>

        <div class="w-[1px] h-4 bg-neutral-800"></div>

        <!-- Escala Cinta -->
        <div class="flex items-center gap-2">
          <span class="text-[10px] font-mono text-neutral-400 uppercase">Cinta:</span>
          <input
            type="range"
            min="0.70"
            max="1.50"
            step="0.05"
            value={uiScale.ticker}
            on:input={(e) => matchStore.setTickerScale(e.target.value)}
            class="w-16 accent-amber-500 h-1 bg-neutral-800 rounded cursor-pointer"
          />
          <span class="text-[10px] font-mono font-bold text-amber-400 w-8">{Math.round(uiScale.ticker * 100)}%</span>
        </div>
      </div>

      <!-- Activar / Desactivar Fotos -->
      <button
        on:click={() => matchStore.toggleAvatars()}
        class="px-3 py-2 rounded-xl text-xs font-bold border flex items-center gap-1.5 transition
          {showAvatars ? 'bg-neutral-800 border-neutral-700 text-white' : 'bg-neutral-900 border-neutral-800 text-neutral-500'}"
      >
        <Image size={15} class={showAvatars ? 'text-amber-400' : 'text-neutral-500'} />
        Fotos: {showAvatars ? 'ON' : 'OFF'}
      </button>

      <!-- Control Maestro de Turnos -->
      <button
        on:click={() => matchStore.toggleTurns()}
        class="px-3.5 py-2 rounded-xl text-xs font-bold border flex items-center gap-2 transition
          {turns.enabled ? 'bg-amber-950/70 border-amber-500/60 text-amber-300' : 'bg-neutral-800 border-neutral-700 text-neutral-400'}"
      >
        {#if turns.enabled}
          <ToggleRight size={18} class="text-amber-400" /> Turnos: ON
        {:else}
          <ToggleLeft size={18} /> Turnos: OFF
        {/if}
      </button>

      {#if turns.enabled}
        <button
          on:click={() => matchStore.switchTurn()}
          class="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-black text-xs font-black rounded-xl flex items-center gap-1.5 transition active:scale-95 shadow-md"
        >
          <UserCheck size={15} /> Cambiar Turno
        </button>
      {/if}

      <!-- Invertir Troneras -->
      <button
        on:click={() => matchStore.swapPockets()}
        class="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 border border-white/10 text-xs font-bold rounded-xl flex items-center gap-2 transition active:scale-95"
      >
        <ArrowLeftRight size={15} class="text-amber-400" /> Invertir (L ⇄ R)
      </button>

      <select
        value={$matchStore.modality}
        on:change={(e) => matchStore.updateState(s => ({ ...s, modality: e.target.value }))}
        class="bg-neutral-900 border border-neutral-700 text-xs font-bold rounded-xl px-3 py-2 text-white outline-none cursor-pointer"
      >
        <option value="ONE POCKET">ONE POCKET</option>
        <option value="BOLA 8">BOLA 8 (Próximamente)</option>
        <option value="BOLA 9">BOLA 9 (Próximamente)</option>
      </select>
    </div>
  </header>

  <!-- TARJETAS DE JUGADORES -->
  <main class="grid grid-cols-2 gap-6 items-start">
    <PlayerCard playerKey="p1" title="Jugador 1" />
    <PlayerCard playerKey="p2" title="Jugador 2" />
  </main>

  <!-- CONTROLES DEL RELOJ DE TIRO -->
  <div class="bg-[#10131c] border border-white/15 rounded-2xl p-5 flex items-center justify-between shadow-xl">
    <div class="flex items-center gap-3">
      <Clock size={22} class="text-amber-400" />
      <div>
        <h4 class="text-sm font-bold uppercase font-mono tracking-wider text-white">Reloj de Tiro (Shot Clock)</h4>
        <span class="text-xs text-neutral-400">{timer.enabled ? 'Barra activa bajo el marcador' : 'Oculto'}</span>
      </div>
      <button
        on:click={() => matchStore.toggleTimer()}
        class="ml-4 px-3 py-1.5 text-xs font-bold rounded-lg border transition {timer.enabled ? 'bg-amber-950/70 border-amber-500/50 text-amber-300' : 'bg-neutral-900 border-neutral-700 text-neutral-400'}"
      >
        {timer.enabled ? 'Ocultar Reloj' : 'Mostrar Reloj'}
      </button>
    </div>

    <!-- Botonera centralizada -->
    <div class="flex items-center gap-4">
      
      <div class="flex items-center bg-[#090b10] border border-neutral-700/80 rounded-xl p-1 gap-2 shadow-inner">
        <span class="text-xs font-mono font-bold text-neutral-400 pl-2.5">Fijar:</span>
        <input
          type="number"
          min="5"
          max="180"
          bind:value={customSecondsInput}
          class="w-14 bg-neutral-900 border border-neutral-700 focus:border-amber-500 text-sm font-mono font-black text-amber-400 outline-none text-center py-1.5 rounded-lg"
        />
        <span class="text-xs font-mono text-neutral-400">s</span>
        <button
          on:click={() => matchStore.setCustomTimer(customSecondsInput)}
          class="px-3.5 py-1.5 bg-neutral-800 hover:bg-neutral-700 active:scale-95 text-xs font-bold text-white rounded-lg transition border border-white/5"
        >
          Aplicar
        </button>
      </div>

      <span class="text-3xl font-black font-mono text-amber-400 w-16 text-center drop-shadow-[0_0_8px_rgba(250,204,21,0.5)]">
        {Math.ceil(timer.seconds)}s
      </span>

      <button
        on:click={() => matchStore.setTimerRunning(!timer.running)}
        class="px-6 py-2.5 {timer.running ? 'bg-amber-500 text-black' : 'bg-emerald-600 text-white'} text-sm font-black rounded-xl flex items-center gap-2 transition active:scale-95 shadow-lg"
      >
        {#if timer.running}
          <Pause size={17} /> Pausar
        {:else}
          <Play size={17} /> Iniciar
        {/if}
      </button>

      <button
        on:click={() => matchStore.resetTimer(timer.maxSeconds)}
        class="px-4 py-2.5 bg-neutral-800 hover:bg-neutral-700 active:scale-95 text-xs font-bold text-white rounded-xl flex items-center gap-2 transition border border-white/10"
      >
        <RotateCcw size={16} class="text-amber-400" /> Reiniciar
      </button>

    </div>
  </div>

  <!-- GESTOR DE TICKER / MARCAS -->
  <TickerAdmin />

</div>
